# simulate_traffic: Simulate traffic accidents for two groups
# Input:
# - lambda_1: numeric, specifying the rate parameter for the Poisson distribution of group 1 (no limit). Must be a positive numeric value.
# - lambda_2: numeric, specifying the rate parameter for the Poisson distribution of group 2 (limit). Must be a positive numeric value.
# - n: integer, specifying the number of observations to simulate for each group. Must be a positive integer (default = 75).
# Output: A list containing two numeric vectors, y_1 and y_2, which are the simulated counts of traffic accidents for groups 1 (no limit) and 2 (limit) respectively.
# The function includes signal conditions to check if lambda_1 and lambda_2 are positive numerics, and n is a positive integer.
simulate_traffic <- function(lambda_1, lambda_2, n = 75) {
  
  if (!is.numeric(lambda_1) || lambda_1 <= 0) {
    stop("lambda_1 must be a positive numeric value")
  }
  if (!is.numeric(lambda_2) || lambda_2 <= 0) {
    stop("lambda_2 must be a positive numeric value")
  }
  
  if (!is.numeric(n) || n <= 0 || n != as.integer(n)) {
    stop("n must be a positive integer")
  }
  
  y_1 <- rpois(n, lambda_1) 
  y_2 <- rpois(n, lambda_2)  
  return(list(y_1 = y_1, y_2 = y_2))
}

# Unit Test to Make Sure the simulate_traffic function returns the correct output:

test_that("simulate_traffic returns correct output", {
  test_lambda_1 <- 10
  test_lambda_2 <- 20
  test_n <- 75
  result <- simulate_traffic(test_lambda_1, test_lambda_2, test_n)
  
  expect_true(is.list(result))
  expect_true(all(sapply(result, is.numeric)))
  expect_equal(length(result$y_1), test_n)
  expect_equal(length(result$y_2), test_n)
})
