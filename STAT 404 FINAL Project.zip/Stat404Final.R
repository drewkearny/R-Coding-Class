# Load Libraries
library(tidyverse)
library(testthat)
# Load data
data(Traffic, package = "MASS")


options(width = 120)

# simulate_traffic: Simulate traffic accidents for two groups
# Input:
# - lambda_1: numeric, specifying the rate parameter for the Poisson distribution of group 1 (no limit). Must be a positive numeric value.
# - lambda_2: numeric, specifying the rate parameter for the Poisson distribution of group 2 (limit). Must be a positive numeric value.
# - n: integer, specifying the number of observations to simulate for each group. Must be a positive integer (default = 75).
# Output: A list containing two numeric vectors, y_1 and y_2, which are the simulated counts of traffic accidents for groups 1 (no limit) and 2 (limit) respectively.
# The function includes signal conditions to check if lambda_1 and lambda_2 are positive numerics, and n is a positive integer.
simulate_traffic <- function(lambda_1, lambda_2, n = 75) {
  
  if (!is.numeric(lambda_1) || lambda_1 <= 0) {
    stop("lambda_1 must be a positive numeric value")
  }
  if (!is.numeric(lambda_2) || lambda_2 <= 0) {
    stop("lambda_2 must be a positive numeric value")
  }
  
  if (!is.numeric(n) || n <= 0 || n != as.integer(n)) {
    stop("n must be a positive integer")
  }
  
  y_1 <- rpois(n, lambda_1) 
  y_2 <- rpois(n, lambda_2)  
  return(list(y_1 = y_1, y_2 = y_2))
}

# Unit Test to Make Sure the simulate_traffic function returns the correct output:

test_that("simulate_traffic returns correct output", {
  test_lambda_1 <- 10
  test_lambda_2 <- 20
  test_n <- 75
  result <- simulate_traffic(test_lambda_1, test_lambda_2, test_n)
  
  expect_true(is.list(result))
  expect_true(all(sapply(result, is.numeric)))
  expect_equal(length(result$y_1), test_n)
  expect_equal(length(result$y_2), test_n)
})


# repeat_simulation: Repeats the simulation of traffic accidents multiple times
# Input:
# - lambda_1: numeric, specifying the rate parameter for the Poisson distribution of group 1 (no limit). Must be a positive numeric value.
# - lambda_2: numeric, specifying the rate parameter for the Poisson distribution of group 2 (limit). Must be a positive numeric value.
# - n: integer, specifying the number of observations to simulate for each group. Must be a positive integer.
# - num_simulations: integer, specifying the number of times the simulation should be repeated. Must be a positive integer.
# Output: A numeric vector containing the differences in sample means between y_1 (no limit) and y_2 (limit) for each simulation.
# The function includes a signal condition to check if num_simulations is a positive integer.
repeat_simulation <- function(lambda_1, lambda_2, n, num_simulations) {
  if (!is.numeric(num_simulations) || num_simulations <= 0 || num_simulations != as.integer(num_simulations)) {
    stop("num_simulations must be a positive integer")
  }
  
  sim_results <- replicate(num_simulations, simulate_traffic(lambda_1, lambda_2, n), simplify = FALSE)
  differences <- sapply(sim_results, function(sim) mean(sim$y_1) - mean(sim$y_2))
  
  return(differences)
}

# summarize_simulation: Summarizes the results of a simulation by providing a summary of differences, variance, and density plot.
# Input:
# - simulation_differences: numeric vector, representing the differences observed in the simulation data. 
# - show_output: logical, indicating whether to display the outputs (summary, variance, and density plot) and return them. Defaults to TRUE.
# Process:
#   1. Calculates and prints the summary of the simulation differences.
#   2. Calculates and prints the variance of the simulation differences, formatted with 4 decimal places.
#   3. Generates and plots the density of the simulation differences.
# Output:
# - If show_output is TRUE, returns a list containing:
#   - summary: The summary of the simulation differences.
#   - variance_output: A formatted string showing the variance.
#   - density_plot: The density plot object for the simulation differences.
# Note: The function is designed to provide a comprehensive view of the simulation data, aiding in understanding its distribution and variability.
summarize_simulation <- function(simulation_differences, show_output = TRUE) {
  
  # Get the summary 
  simulation_summary <- summary(simulation_differences)
  print(simulation_summary)
  
  # Get the variance
  simulation_variance <- var(simulation_differences)
  variance_output <- paste("The variance for the difference of means is:", format(simulation_variance, digits = 4, nsmall = 4))
  print(variance_output)
  
  # Generate and plot the density
  simulation_density <- density(simulation_differences)
  plot(simulation_density)
  
  # Return all the things if show_output is TRUE
  if (show_output) {
    return(list(summary = simulation_summary, variance_output = variance_output, density_plot = simulation_density))
  }
}

# For lambda1 = 25, lambda2 = 15, and n = 75
differences_75 <- repeat_simulation(25, 15, 75, 1000)
summary(differences_75)
hist(differences_75, main = "Distribution of Differences in Sample Means (n = 75)")

variance_75 <- var(differences_75)
paste("The variance for the difference of means at n=75 is:", format(variance_75, digits = 4, nsmall = 4))

density75 <- density(differences_75)
plot(density75)


lambda_grid <- seq(10, 50, by = 5)
difference_summaries <- sapply(lambda_grid, function(lam) {
  repeat_simulation(lam, 15, 75, 1000)
})

summary(difference_summaries)
hist(difference_summaries, breaks=10)
hist(difference_summaries, breaks=75)

# Plotting the results
boxplot(difference_summaries, names = lambda_grid, main = "Differences in Sample Means Across Lambda_1")

# Simulation 3

differences_150 <- repeat_simulation(25, 15, 150, 1000)
differences_300 <- repeat_simulation(25, 15, 300, 1000)

summary(differences_150)

summary(differences_300)

variance_150 <- var(differences_150)
paste("The variance for the difference of means at n=150 is:", format(variance_150, digits = 4, nsmall = 4))

density_150 <- density(differences_150)
plot(density_150)

variance_300 <- var(differences_300)
paste("The variance for the difference of means at n=300 is:", format(variance_300, digits = 4, nsmall = 4))

density_300<- density(differences_300)
plot(density_300)

par(mfrow = c(1, 3))
hist(differences_75, main = "n = 75")
hist(differences_150, main = "n = 150")
hist(differences_300, main = "n = 300")


#
# Exploratory Data Analysis
#
# Exploratory Data Analysis
summary(Traffic)

# Create numeric version of the variable for exploration
Traffic$limit_numeric <- as.numeric(Traffic$limit == "yes")

# Correlation Analysis
cor(Traffic$y, Traffic$limit_numeric)

table(Traffic$y)
table(Traffic$limit)

# See if means are significantly different with or without limit
t.test(Traffic$y[Traffic$limit_numeric==0],
       Traffic$y[Traffic$limit_numeric==1])

# Visual Plots
pairs(Traffic[2:3])
hist(Traffic$y, xlab = "Accidents", main = paste("Histogram of Traffic Accidents"),
     breaks = 20)
plot(Traffic$y)
#box plot
plot(Traffic$limit, Traffic$y, main = "Box Plot", xlab = "Speed Limit", ylab = "Accidents")


# Checking Assumptions for model without removing intercept
linear_mod <- lm(y ~ limit, data = Traffic)
plot(linear_mod$fitted.values, residuals(linear_mod), main = "Residuals vs Fitted", xlab = "Fitted Values", ylab = "Residuals")
abline(h = 0, col = "blue")

qqnorm(residuals(linear_mod))
qqline(residuals(linear_mod), col = "red")

plot(linear_mod)

shapiro.test(residuals(linear_mod))

# Log transformation is needed due to normality assumptions
Traffic$y_log <- log(Traffic$y + 1)
model_log <- lm(y_log ~ limit, data = Traffic)
plot(model_log$fitted.values, residuals(model_log), main = "Residuals vs Fitted", xlab = "Fitted Values", ylab = "Residuals")
abline(h = 0, col = "blue")

plot(model_log)

qqnorm(residuals(model_log))
qqline(residuals(model_log), col = "red")

shapiro.test(residuals(model_log))

#
# Data Analysis
#
# Conducting a linear regression
# Linear model, Remove Intercept with -1 
linear_fit <- lm(y ~ limit - 1, data = Traffic)
summary(linear_fit)
coef(linear_fit)
# Checking assumptions of the model
plot(linear_fit)
shapiro.test(residuals(linear_fit))


# Linear model on log transformed Response, Remove Intercept with -1 
log_trans_fit <-lm(y_log ~ limit - 1, data = Traffic)
summary(log_trans_fit)
coef(log_trans_fit)
# Checking assumptions of the model
plot(log_trans_fit)
shapiro.test(residuals(log_trans_fit))
