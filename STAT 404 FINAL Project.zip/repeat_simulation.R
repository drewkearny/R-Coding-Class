# repeat_simulation: Repeats the simulation of traffic accidents multiple times
# Input:
# - lambda_1: numeric, specifying the rate parameter for the Poisson distribution of group 1 (no limit). Must be a positive numeric value.
# - lambda_2: numeric, specifying the rate parameter for the Poisson distribution of group 2 (limit). Must be a positive numeric value.
# - n: integer, specifying the number of observations to simulate for each group. Must be a positive integer.
# - num_simulations: integer, specifying the number of times the simulation should be repeated. Must be a positive integer.
# Output: A numeric vector containing the differences in sample means between y_1 (no limit) and y_2 (limit) for each simulation.
# The function includes a signal condition to check if num_simulations is a positive integer.
repeat_simulation <- function(lambda_1, lambda_2, n, num_simulations) {
  if (!is.numeric(num_simulations) || num_simulations <= 0 || num_simulations != as.integer(num_simulations)) {
    stop("num_simulations must be a positive integer")
  }
  
  sim_results <- replicate(num_simulations, simulate_traffic(lambda_1, lambda_2, n), simplify = FALSE)
  differences <- sapply(sim_results, function(sim) mean(sim$y_1) - mean(sim$y_2))
  
  return(differences)
}

# summarize_simulation: Summarizes the results of a simulation by providing a summary of differences, variance, and density plot.
# Input:
# - simulation_differences: numeric vector, representing the differences observed in the simulation data. 
# - show_output: logical, indicating whether to display the outputs (summary, variance, and density plot) and return them. Defaults to TRUE.
# Process:
#   1. Calculates and prints the summary of the simulation differences.
#   2. Calculates and prints the variance of the simulation differences, formatted with 4 decimal places.
#   3. Generates and plots the density of the simulation differences.
# Output:
# - If show_output is TRUE, returns a list containing:
#   - summary: The summary of the simulation differences.
#   - variance_output: A formatted string showing the variance.
#   - density_plot: The density plot object for the simulation differences.
# Note: The function is designed to provide a comprehensive view of the simulation data, aiding in understanding its distribution and variability.
summarize_simulation <- function(simulation_differences, show_output = TRUE) {
  
  # Get the summary 
  simulation_summary <- summary(simulation_differences)
  print(simulation_summary)
  
  # Get the variance
  simulation_variance <- var(simulation_differences)
  variance_output <- paste("The variance for the difference of means is:", format(simulation_variance, digits = 4, nsmall = 4))
  print(variance_output)
  
  # Generate and plot the density
  simulation_density <- density(simulation_differences)
  plot(simulation_density)
  
  # Return all the things if show_output is TRUE
  if (show_output) {
    return(list(summary = simulation_summary, variance_output = variance_output, density_plot = simulation_density))
  }
}